/*
 * APP_Functions_Interface.c
 *
 * Created: 5/7/2023 4:33:25 PM
 *  Author: aly
 */ 
#include "APP_Functions_Private.h"

/***********************************************/
/***********************************************/
void System_Tgl(void){
	while(!ON_OFF_Button_pressed()){
		SEVSEG_Disable1();SEVSEG_Disable2();
		Heater_LED_OFF();Heater_OFF();
		Cooler_LED_OFF();Cooler_OFF();
	}
}

/***********************************************/
/***********************************************/
void Functions_Initializ(void){
	UP_Button_Initialization();
	Down_Button_Initialization();
	ON_OFF_Button_Initialization();
	Heater_Initializ();
	Cooler_Initializ();
	Heater_LED_Initializ();
	Cooler_LED_Initializ();
	SEVSEG_Initialize();
	Temp_Sensor_Initializ();
	Timer0_Initialize();
}

/***********************************************/
/***********************************************/
UINT8_t temp_set_value = 0;			// Temperature set value
UINT16_t waiting_counter = 0;		// Counter for 5s if no response.
void Temperature_setting_mode(void){
	temp_set_value = EEPROM_read(10);
	while(waiting_counter < 5){
		UINT16_t i;
		for(i=0; i < 225 ; i++){
			SEVSEG_Display(temp_set_value);
			if(UP_Button_pressed()){
				if(temp_set_value < 75){
					temp_set_value += 5;
				}
				waiting_counter = 0;
			}
			if(Down_Button_pressed()){
				if(temp_set_value > 35){
					temp_set_value -= 5;
				}
				waiting_counter = 0;
			}
		}
		SEVSEG_Disable1();
		SEVSEG_Disable2();
		_delay_ms(100);
		waiting_counter++;
	}
	waiting_counter = 0;
	// Store EEPROM:
	EEPROM_write_update(10 , temp_set_value);
}

/***********************************************/
/***********************************************/
UINT32_t ten_readings = 0;			// Stack Of Ten Sensor Readings.
UINT16_t ovf_time_count = 0;		// Enter every 100ms
UINT16_t one_sec_counter = 0;		// Enter every 10 ovf_time_count = 10*100 = 1s
void Every_100ms(void){
	ovf_time_count = 0;
	ten_readings += (Temp_Sensor_Read()/11);
	one_sec_counter++;
	TCNT0 = 203;
}

/***********************************************/
/***********************************************/
UINT8_t tempsensor_value = 0;		// The Average 10 reading is calculated and saved here.
bool HeaterOn_flag = false;
void Every_1s(void){
	tempsensor_value = ten_readings/10;
	if((temp_set_value > tempsensor_value)){
		if((temp_set_value-tempsensor_value) >= 5){
			HeaterOn_flag = true;
			Heater_ON();
			Cooler_LED_OFF();Cooler_OFF();
		}
	}
	if((temp_set_value < tempsensor_value)){
		if((tempsensor_value - temp_set_value) >= 5){
			Cooler_LED_ON();Cooler_ON();
			Heater_LED_OFF();Heater_OFF();HeaterOn_flag = false;
		}
	}
	if(HeaterOn_flag == true){
		Heater_LED_TGL();
	}
	ten_readings = 0;
	one_sec_counter=0;
}