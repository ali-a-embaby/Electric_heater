/*
 * APP_Functions_Private.h
 *
 * Created: 5/7/2023 4:33:41 PM
 *  Author: aly
 */ 


#ifndef APP_FUNCTIONS_PRIVATE_H_
#define APP_FUNCTIONS_PRIVATE_H_

#include "Down_Button_Private.h"
#include "UP_Button_Private.h"
#include "ON_OFF_Button_Private.h"
#include "Heater_LED_Private.h"
#include "Cooler_LED_Private.h"
#include "SEVSEG_Private.h"
#include "Temp_Sensor_Private.h"
#include "Heater_Private.h"
#include "Cooler_Private.h"

void Functions_Initializ(void);
void Temperature_setting_mode(void);
void System_Tgl(void);
void Every_100ms(void);
void Every_1s(void);

#endif /* APP_FUNCTIONS_PRIVATE_H_ */