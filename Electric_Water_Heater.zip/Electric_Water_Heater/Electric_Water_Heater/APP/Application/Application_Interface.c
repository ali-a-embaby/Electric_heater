/*
 * Application_Interface.c
 *
 * Created: 5/7/2023 4:34:00 PM
 *  Author: aly
 */ 
#include "Application_Private.h"

extern UINT16_t ovf_time_count;				// Enter every 100ms
extern UINT16_t one_sec_counter;			// Enter every 10 ovf_time_count = 10*100 = 1s
extern UINT8_t	temp_set_value;				// Temperature set value

void Electric_Heater_app(){
	Functions_Initializ();
	//EEPROM_write_update(10 , 60);			//Setting initial Temp for the first time.
	temp_set_value = EEPROM_read(10);		//Read the set temperature value from eeprom.
	while(1){
		Electric_Heater_app_action();
	}
}
void Electric_Heater_app_action(){
	SEVSEG_Display(Temp_Sensor_Read()/11);	// Temp sensor is Analogue reads so we need to convert 1023 to 93 we divide by 11.
	if(ON_OFF_Button_pressed()){
		System_Tgl();						// Toggle the system on and off.
	}
	if(UP_Button_pressed()){
		Temperature_setting_mode();
	}
	if(Down_Button_pressed()){
		Temperature_setting_mode();
	}
}
ISR(TIMER0_OVF_vect)						// Interrupt for every Timer 0 over flow.
{
	if(ovf_time_count == 7){				// Enter every 100ms.
		Every_100ms();
	}
	if(one_sec_counter == 10){				// 10 of 100ms = 1s.
		Every_1s();
	}
	ovf_time_count++;						// Over Flow counter.
}