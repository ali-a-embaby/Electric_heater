/*
 * Application_Private.h
 *
 * Created: 5/7/2023 4:34:09 PM
 *  Author: aly
 */ 


#ifndef APPLICATION_PRIVATE_H_
#define APPLICATION_PRIVATE_H_

#include "APP_Functions_Private.h"

void Electric_Heater_app();
void Electric_Heater_app_action();

#endif /* APPLICATION_PRIVATE_H_ */