/*
 * Down_Button_Interface.c
 *
 * Created: 5/7/2023 4:50:19 PM
 *  Author: aly
 */ 
#include "Down_Button_Private.h"
bool Down_Button_OneTime = LOW;
void Down_Button_Initialization(void){
	DIO_SetPin_Direction(Down_Button_PORT , Down_Button_PIN , Down_Button_INPUT);
}
bool Down_Button_pressed(){
	if((DIO_GetPin_Value(Down_Button_PORT,Down_Button_PIN)) == HIGH){
		if(Down_Button_OneTime == LOW){
			Down_Button_OneTime = HIGH;
			return HIGH;
		}
		}else{
		Down_Button_OneTime = LOW;
		return LOW;
	}
	return LOW;
}