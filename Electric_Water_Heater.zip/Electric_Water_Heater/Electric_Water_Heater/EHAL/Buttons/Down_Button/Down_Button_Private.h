/*
 * Down_Button_Private.h
 *
 * Created: 5/7/2023 4:49:48 PM
 *  Author: aly
 */ 


#ifndef DOWN_BUTTON_PRIVATE_H_
#define DOWN_BUTTON_PRIVATE_H_
// Configuration:
#include "CPU_Configuration.h"
#define Down_Button_PIN		DIO_PIN0
#define Down_Button_PORT	DIO_PORTB
#define Down_Button_INPUT	DIO_INPUT
// Function Prototype:
void Down_Button_Initialization(void);
bool Down_Button_pressed();

#endif /* DOWN_BUTTON_PRIVATE_H_ */