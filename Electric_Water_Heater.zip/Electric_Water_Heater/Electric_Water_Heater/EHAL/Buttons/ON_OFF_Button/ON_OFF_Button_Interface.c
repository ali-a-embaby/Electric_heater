/*
 * ON_OFF_Button_Interface.c
 *
 * Created: 5/7/2023 4:51:12 PM
 *  Author: aly
 */ 
#include "ON_OFF_Button_Private.h"
bool ON_OFF_Button_OneTime = LOW;
void ON_OFF_Button_Initialization(void){
	DIO_SetPin_Direction(ON_OFF_Button_PORT , ON_OFF_Button_PIN , ON_OFF_Button_INPUT);
}
bool ON_OFF_Button_pressed(){
	if((DIO_GetPin_Value(ON_OFF_Button_PORT,ON_OFF_Button_PIN)) == HIGH){
		if(ON_OFF_Button_OneTime == LOW){
			ON_OFF_Button_OneTime = HIGH;
			return HIGH;
		}
		}else{
		ON_OFF_Button_OneTime = LOW;
		return LOW;
	}
	return LOW;
}