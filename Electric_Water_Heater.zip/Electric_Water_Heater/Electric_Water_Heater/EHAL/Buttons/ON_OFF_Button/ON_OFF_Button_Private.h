/*
 * ON_OFF_Button_Private.h
 *
 * Created: 5/7/2023 4:51:21 PM
 *  Author: aly
 */ 


#ifndef ON_OFF_BUTTON_PRIVATE_H_
#define ON_OFF_BUTTON_PRIVATE_H_

#include "CPU_Configuration.h"
#define ON_OFF_Button_PIN		DIO_PIN2
#define ON_OFF_Button_PORT		DIO_PORTD
#define ON_OFF_Button_INPUT		DIO_INPUT
// Function Prototype:
void ON_OFF_Button_Initialization(void);
bool ON_OFF_Button_pressed();

#endif /* ON_OFF_BUTTON_PRIVATE_H_ */