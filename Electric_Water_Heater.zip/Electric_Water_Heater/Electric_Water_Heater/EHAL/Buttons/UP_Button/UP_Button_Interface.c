/*
 * UP_Button_Interface.c
 *
 * Created: 5/7/2023 4:47:10 PM
 *  Author: aly
 */ 
#include "UP_Button_Private.h"
bool UP_Button_OneTime = LOW;
void UP_Button_Initialization(void){
	DIO_SetPin_Direction(UP_Button_PORT , UP_Button_PIN , UP_Button_INPUT);
}
bool UP_Button_pressed(){
	if((DIO_GetPin_Value(UP_Button_PORT,UP_Button_PIN)) == HIGH){
		if(UP_Button_OneTime == LOW){
			UP_Button_OneTime = HIGH;
			return HIGH;
		}
		}else{
		UP_Button_OneTime = LOW;
		return LOW;
	}
	return LOW;
}