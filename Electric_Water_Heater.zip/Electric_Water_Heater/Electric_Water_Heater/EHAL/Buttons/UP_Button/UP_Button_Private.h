/*
 * UP_Button_Private.h
 *
 * Created: 5/7/2023 4:47:56 PM
 *  Author: aly
 */ 


#ifndef UP_BUTTON_PRIVATE_H_
#define UP_BUTTON_PRIVATE_H_
// Configuration:
#include "CPU_Configuration.h"
#define UP_Button_PIN		DIO_PIN6
#define UP_Button_PORT		DIO_PORTD
#define UP_Button_INPUT		DIO_INPUT
// Function Prototype:
void UP_Button_Initialization(void);
bool UP_Button_pressed();

#endif /* UP_BUTTON_PRIVATE_H_ */