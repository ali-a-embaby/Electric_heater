/*
 * Cooler_Interfacing.c
 *
 * Created: 5/7/2023 5:44:55 PM
 *  Author: aly
 */ 
#include "Cooler_Private.h"

void Cooler_Initializ(void){
	DIO_SetPin_Direction(Cooler_PORT,Cooler_PIN,Cooler_OUTPUT);
}
void Cooler_ON(void){
	DIO_SetPin_Value(Cooler_PORT,Cooler_PIN,Cooler_HIGH);
}
void Cooler_OFF(void){
	DIO_SetPin_Value(Cooler_PORT,Cooler_PIN,Cooler_LOW);
}
void Cooler_TGL(void){
	DIO_TglPin_Value(Cooler_PORT,Cooler_PIN);
}