/*
 * Cooler_Private.h
 *
 * Created: 5/7/2023 5:45:15 PM
 *  Author: aly
 */ 


#ifndef COOLER_PRIVATE_H_
#define COOLER_PRIVATE_H_

// Configuration:
#include "CPU_Configuration.h"
#define Cooler_PIN		DIO_PIN2
#define Cooler_PORT		DIO_PORTA

#define Cooler_OUTPUT	DIO_OUTPUT

#define Cooler_HIGH		DIO_HIGH
#define Cooler_LOW		DIO_LOW
// Function Prototype:
void Cooler_Initializ(void);
void Cooler_ON(void);
void Cooler_OFF(void);
void Cooler_TGL(void);


#endif /* COOLER_PRIVATE_H_ */