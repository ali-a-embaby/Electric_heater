/*
 * Heater_Interface.c
 *
 * Created: 5/7/2023 5:43:28 PM
 *  Author: aly
 */ 
#include "Heater_Private.h"

void Heater_Initializ(void){
	DIO_SetPin_Direction(Heater_PORT,Heater_PIN,Heater_OUTPUT);
}
void Heater_ON(void){
	DIO_SetPin_Value(Heater_PORT,Heater_PIN,Heater_HIGH);
}
void Heater_OFF(void){
	DIO_SetPin_Value(Heater_PORT,Heater_PIN,Heater_LOW);
}
void Heater_TGL(void){
	DIO_TglPin_Value(Heater_PORT,Heater_PIN);
}