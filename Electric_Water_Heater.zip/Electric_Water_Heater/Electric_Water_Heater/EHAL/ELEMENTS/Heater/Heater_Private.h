/*
 * Heater_Private.h
 *
 * Created: 5/7/2023 5:43:37 PM
 *  Author: aly
 */ 


#ifndef HEATER_PRIVATE_H_
#define HEATER_PRIVATE_H_

// Configuration:
#include "CPU_Configuration.h"
#define Heater_PIN		DIO_PIN3
#define Heater_PORT		DIO_PORTD

#define Heater_OUTPUT	DIO_OUTPUT

#define Heater_HIGH		DIO_HIGH
#define Heater_LOW		DIO_LOW
// Function Prototype:

void Heater_Initializ(void);
void Heater_ON(void);
void Heater_OFF(void);
void Heater_TGL(void);

#endif /* HEATER_PRIVATE_H_ */