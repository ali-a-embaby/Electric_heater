/*
 * Cooler_LED_Interface.c
 *
 * Created: 5/7/2023 4:52:25 PM
 *  Author: aly
 */ 
#include "Cooler_LED_Private.h"

void Cooler_LED_Initializ(void){
	DIO_SetPin_Direction(Cooler_LED_PORT,Cooler_LED_PIN,Cooler_LED_OUTPUT);
}
void Cooler_LED_ON(void){
	DIO_SetPin_Value(Cooler_LED_PORT,Cooler_LED_PIN,Cooler_LED_HIGH);
}
void Cooler_LED_OFF(void){
	DIO_SetPin_Value(Cooler_LED_PORT,Cooler_LED_PIN,Cooler_LED_LOW);
}
void Cooler_LED_TGL(void){
	DIO_TglPin_Value(Cooler_LED_PORT,Cooler_LED_PIN);
}