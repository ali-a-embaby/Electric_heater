/*
 * Cooler_LED_Private.h
 *
 * Created: 5/7/2023 4:53:16 PM
 *  Author: aly
 */ 


#ifndef COOLER_LED_PRIVATE_H_
#define COOLER_LED_PRIVATE_H_
// Configuration:
#include "CPU_Configuration.h"
#define Cooler_LED_PIN		DIO_PIN7
#define Cooler_LED_PORT		DIO_PORTC

#define Cooler_LED_OUTPUT	DIO_OUTPUT

#define Cooler_LED_HIGH		DIO_HIGH
#define Cooler_LED_LOW		DIO_LOW

// Function Prototype:
void Cooler_LED_Initializ(void);
void Cooler_LED_ON(void);
void Cooler_LED_OFF(void);
void Cooler_LED_TGL(void);

#endif /* COOLER_LED_PRIVATE_H_ */