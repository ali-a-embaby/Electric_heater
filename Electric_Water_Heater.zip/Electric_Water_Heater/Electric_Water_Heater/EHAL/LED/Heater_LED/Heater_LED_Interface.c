/*
 * Heater_LED_Interface.c
 *
 * Created: 5/7/2023 4:52:04 PM
 *  Author: aly
 */ 
#include "Heater_LED_Private.h"

void Heater_LED_Initializ(void){
	DIO_SetPin_Direction(Heater_LED_PORT,Heater_LED_PIN,Heater_LED_OUTPUT);
}
void Heater_LED_ON(void){
	DIO_SetPin_Value(Heater_LED_PORT,Heater_LED_PIN,Heater_LED_HIGH);
}
void Heater_LED_OFF(void){
	DIO_SetPin_Value(Heater_LED_PORT,Heater_LED_PIN,Heater_LED_LOW);
}
void Heater_LED_TGL(void){
	DIO_TglPin_Value(Heater_LED_PORT,Heater_LED_PIN);
}