/*
 * Heater_LED_Private.h
 *
 * Created: 5/7/2023 4:51:55 PM
 *  Author: aly
 */ 


#ifndef HEATER_LED_PRIVATE_H_
#define HEATER_LED_PRIVATE_H_

// Configuration:
#include "CPU_Configuration.h"
#define Heater_LED_PIN		DIO_PIN2
#define Heater_LED_PORT		DIO_PORTC

#define Heater_LED_OUTPUT	DIO_OUTPUT

#define Heater_LED_HIGH		DIO_HIGH
#define Heater_LED_LOW		DIO_LOW

// Function Prototype:
void Heater_LED_Initializ(void);
void Heater_LED_ON(void);
void Heater_LED_OFF(void);
void Heater_LED_TGL(void);

#endif /* HEATER_LED_PRIVATE_H_ */