/*
 * SEVSEG_Interface.c
 *
 * Created: 5/7/2023 4:52:04 PM
 *  Author: aly
 */ 
#include "SEVSEG_Private.h"

void SEVSEG_Initialize(void)
{
	DIO_SetPin_Direction(SEVSEG_DATA_PORT, SEVSEG_A, SEVSEG_OUT);
	DIO_SetPin_Direction(SEVSEG_DATA_PORT, SEVSEG_B, SEVSEG_OUT);
	DIO_SetPin_Direction(SEVSEG_DATA_PORT, SEVSEG_C, SEVSEG_OUT);
	DIO_SetPin_Direction(SEVSEG_DATA_PORT, SEVSEG_D, SEVSEG_OUT);
	
	DIO_SetPin_Direction(SEVSEG_CNTRL_PORT, SEVSEG_EN1, SEVSEG_OUT);
	DIO_SetPin_Direction(SEVSEG_CNTRL_PORT, SEVSEG_EN2, SEVSEG_OUT);
	DIO_SetPin_Direction(SEVSEG_CNTRL_PORT, SEVSEG_DIP, SEVSEG_OUT);	
}
void SEVSEG_Enable1(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_EN1, SEVSEG_HIGH);
}
void SEVSEG_Disable1(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_EN1, SEVSEG_LOW);
}
void SEVSEG_Enable2(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_EN2, SEVSEG_HIGH);
}
void SEVSEG_Disable2(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_EN2, SEVSEG_LOW);
}
void SEVSEG_DIP_Enable(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_DIP, SEVSEG_HIGH);
}
void SEVSEG_DIP_Disable(void)
{
	DIO_SetPin_Value(SEVSEG_CNTRL_PORT, SEVSEG_DIP, SEVSEG_LOW);
}
void SEVSEG_Display(UINT8_t number)
{								
	UINT8_t unit = number % 10;	
	UINT8_t tenth = number / 10;
	SEVSEG = (SEVSEG & 0x0f) | (unit << 4);
	SEVSEG_Enable1();
	SEVSEG_Disable2();
	_delay_ms(2);
	SEVSEG = (SEVSEG & 0x0f) | (tenth << 4);
	SEVSEG_Disable1();
	SEVSEG_Enable2();
	_delay_ms(2);
}