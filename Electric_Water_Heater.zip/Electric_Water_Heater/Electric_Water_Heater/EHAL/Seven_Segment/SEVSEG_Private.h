/*
 * SEVSEG_Private.h
 *
 * Created: 5/7/2023 4:52:04 PM
 *  Author: aly
 */ 
#ifndef SEVSEG_PRIVATE_H_
#define SEVSEG_PRIVATE_H_
#include "CPU_Configuration.h"

//Macros
//Renaming ports
#define SEVSEG				 PORTA
#define SEVSEG_DATA_PORT	 DIO_PORTA
#define SEVSEG_CNTRL_PORT	 DIO_PORTB
//Renaming pins
#define SEVSEG_A			DIO_PIN4
#define SEVSEG_B			DIO_PIN5
#define SEVSEG_C			DIO_PIN6
#define SEVSEG_D			DIO_PIN7
#define SEVSEG_EN1			DIO_PIN1
#define SEVSEG_EN2			DIO_PIN2
#define SEVSEG_DIP			DIO_PIN3
//Renaming state
#define SEVSEG_OUT		DIO_OUTPUT
//Renaming Status
#define SEVSEG_LOW			 DIO_LOW
#define SEVSEG_HIGH			 DIO_HIGH

void SEVSEG_Initialize(void);
void SEVSEG_Enable1(void);
void SEVSEG_Disable1(void);
void SEVSEG_Enable2(void);
void SEVSEG_Disable2(void);
void SEVSEG_DIP_Enable(void);
void SEVSEG_DIP_Disable(void);
void SEVSEG_Display(UINT8_t number);




#endif /* SEVSEG_PRIVATE_H_ */