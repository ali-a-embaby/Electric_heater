/*
 * Temp_Sensor_Interface.c
 *
 * Created: 5/7/2023 5:00:40 PM
 *  Author: aly
 */ 
#include "Temp_Sensor_Private.h"

void Temp_Sensor_Initializ(void){
	ADC_Initializ();
}
UINT16_t Temp_Sensor_Read(void){
	return ADC_Read(Temp_Sensor_PIN);
}