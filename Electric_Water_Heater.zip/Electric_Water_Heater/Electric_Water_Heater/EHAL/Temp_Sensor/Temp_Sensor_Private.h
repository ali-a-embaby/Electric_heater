/*
 * Temp_Sensor_Private.h
 *
 * Created: 5/7/2023 5:00:50 PM
 *  Author: aly
 */ 


#ifndef TEMP_SENSOR_PRIVATE_H_
#define TEMP_SENSOR_PRIVATE_H_
// Configuration:
#include "CPU_Configuration.h"
#define Temp_Sensor_PIN			DIO_PIN1
#define Temp_Sensor_PORT		DIO_PORTA
#define Temp_Sensor_INPUT		DIO_INPUT
// Function Prototype:
void Temp_Sensor_Initializ(void);
UINT16_t Temp_Sensor_Read(void);

#endif /* TEMP_SENSOR_PRIVATE_H_ */