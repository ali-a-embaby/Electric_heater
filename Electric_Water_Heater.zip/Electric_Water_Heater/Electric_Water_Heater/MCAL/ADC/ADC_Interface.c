/*
 * ADC_Interface.c
 *
 * Created: 5/7/2023 4:52:04 PM
 *  Author: aly
 */ 
#include "ADC_Private.h"

void ADC_Initializ(void)
{
	CLR_BIT(ADC_ref_voltage ,REFS1); SET_BIT(ADC_ref_voltage ,REFS0); // 01 ref voltage
	SET_BIT(ADC_Cntrl_State ,ADEN); // enable ADC
	SET_BIT(ADC_Cntrl_State ,ADSC); // start ADC conversion
	SET_BIT(ADC_Cntrl_State ,ADPS0); // 3 pins to select division factor Prescaler 125kHz
	SET_BIT(ADC_Cntrl_State ,ADPS1);
	SET_BIT(ADC_Cntrl_State ,ADPS2);
}
UINT16_t ADC_Read(UINT8_t channel)
{
	ADC_ref_voltage &= 0xf0;
	ADC_ref_voltage |= channel;
	SET_BIT(ADC_Cntrl_State, ADSC);
	while(GET_BIT(ADC_Cntrl_State,ADSC));
	return ADC;
}