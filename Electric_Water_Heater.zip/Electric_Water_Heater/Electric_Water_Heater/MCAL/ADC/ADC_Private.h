/*
 * ADC_Private.h
 *
 * Created: 5/7/2023 4:52:04 PM
 *  Author: aly
 */ 


#ifndef ADC_PRIVATE_H_
#define ADC_PRIVATE_H_

#include "CPU_Configuration.h"

#define ADC_ref_voltage ADMUX
#define ADC_Cntrl_State ADCSRA

void ADC_Initializ(void);
UINT16_t ADC_Read(UINT8_t channel);


#endif /* ADC_PRIVATE_H_ */