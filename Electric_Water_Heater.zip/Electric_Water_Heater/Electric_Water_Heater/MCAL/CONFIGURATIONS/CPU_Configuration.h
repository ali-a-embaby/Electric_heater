/*
 * CPU_Configuration.h
 *
 * Created: 5/7/2023 4:42:48 PM
 *  Author: aly
 */ 

#ifndef CPU_CONFIGURATION_H_
#define CPU_CONFIGURATION_H_

#undef F_CPU
#define F_CPU 16000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <stdio.h>
#include "STD_Types.h"
#include "BIT_MATH.h"
#include "MC_Peripherals.h"

#endif /* CPU_CONFIGURATION_H_ */