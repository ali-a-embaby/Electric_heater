/*
 * MC_Peripherals.h
 *
 * Created: 5/7/2023 4:42:57 PM
 *  Author: aly
 */ 



#ifndef MC_PERIPHERALS_H_
#define MC_PERIPHERALS_H_

#include "DIO_Private.h"
#include "ADC_Private.h"
#include "EEPROM_Private.h"
#include "Timer0_Private.h"

#endif /* MC_PERIPHERALS_H_ */