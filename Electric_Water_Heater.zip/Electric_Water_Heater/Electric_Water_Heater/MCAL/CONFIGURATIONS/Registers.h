/*
 * Registers.h
 *
 * Created: 5/7/2023 4:43:11 PM
 *  Author: aly
 */ 

#ifndef REGISTERS_H_
#define REGISTERS_H_

#include "DIO_Address.h"
#include "Timer_0_adresses.h"
#include "ADC_Address.h"

#endif /* REGISTERS_H_ */