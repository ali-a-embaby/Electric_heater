/*
 * EEPROM_Interface.c
 *
 * Created: 5/1/2023 4:09:47 PM
 *  Author: aly
 */ 

#include "EEPROM_Private.h"

void EEPROM_write(UINT32_t uiAddress, UINT8_t ucData)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE));
	/* Set up address and data registers */
	EEAR = uiAddress;
	EEDR = ucData;
	/* Write logical one to EEMWE */
	EECR |= (1<<EEMWE);
	/* Start eeprom write by setting EEWE */
	EECR |= (1<<EEWE);
}
UINT8_t EEPROM_read(UINT32_t uiAddress)
{
	/* Wait for completion of previous write */
	while(EECR & (1<<EEWE));
	/* Set up address register */
	EEAR = uiAddress;
	/* Start eeprom read by writing EERE */
	EECR |= (1<<EERE);
	/* Return data from data register */
	return EEDR;
}
void EEPROM_write_update (UINT32_t uiAddress, UINT8_t ucData) { 
	UINT8_t compare = EEPROM_read(uiAddress);
	if(compare != ucData){
		EEPROM_write(uiAddress , ucData);
	}
}
