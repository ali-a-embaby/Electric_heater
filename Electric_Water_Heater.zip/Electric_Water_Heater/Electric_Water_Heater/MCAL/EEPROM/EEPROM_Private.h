/*
 * EEPROM_Private.h
 *
 * Created: 5/1/2023 3:52:07 PM
 *  Author: aly
 */ 


#ifndef EEPROM_PRIVATE_H_
#define EEPROM_PRIVATE_H_

#include "CPU_Configuration.h"


void EEPROM_write(UINT32_t uiAddress, UINT8_t ucData);
UINT8_t EEPROM_read(UINT32_t uiAddress);

void EEPROM_write_update (UINT32_t uiAddress, UINT8_t ucData);

#endif /* EEPROM_PRIVATE_H_ */