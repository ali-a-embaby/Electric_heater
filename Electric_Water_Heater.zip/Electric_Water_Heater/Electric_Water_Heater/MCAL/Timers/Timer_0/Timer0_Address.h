/*
 * Timer0_Address.h
 *
 * Created: 5/7/2023 8:32:50 PM
 *  Author: aly
 */ 


#ifndef TIMER0_ADDRESS_H_
#define TIMER0_ADDRESS_H_

/*
// Timer 0
#define TCCR0 *((volatile UINT8_t*)0x53)
#define TCNT0 *((volatile UINT8_t*)0x52)
#define OCR0 *((volatile UINT8_t*)0x5C)
#define TIMSK *((volatile UINT8_t*)0x59)
#define TIFR *((volatile UINT8_t*)0x58)

/ * TCCR0 * /
#define FOC0    7
#define WGM00   6
#define COM01   5
#define COM00   4
#define WGM01   3
#define CS02    2
#define CS01    1
#define CS00    0*/





#endif /* TIMER0_ADDRESS_H_ */