/*
 * Timer0_Interface.c
 *
 * Created: 5/7/2023 8:32:34 PM
 *  Author: aly
 */ 

#include "Timer0_Private.h"

void Timer0_Initialize(void){
	
CLR_BIT(TCCR0, FOC0);

CLR_BIT(TCCR0,WGM01);CLR_BIT(TCCR0,WGM00);

CLR_BIT(TCCR0,COM01);CLR_BIT(TCCR0,COM00);

SET_BIT(TCCR0,CS02);CLR_BIT(TCCR0, CS01);SET_BIT(TCCR0, CS00);

SET_BIT(TIMSK,TOIE0);

TCNT0 = 203;

sei();

}