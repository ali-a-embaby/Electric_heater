/*
 * Timer0_Private.h
 *
 * Created: 5/7/2023 8:32:20 PM
 *  Author: aly
 */ 


#ifndef TIMER0_PRIVATE_H_
#define TIMER0_PRIVATE_H_

#include "CPU_Configuration.h"

#define Freq		16000
#define prescaler	1024

void Timer0_Initialize(void);

#endif /* TIMER0_PRIVATE_H_ */