/*
 * Electric_Water_Heater.c
 *
 * Created: 5/7/2023 4:27:16 PM
 * Author : aly
 */ 

#include "Application_Private.h"

int main(void)
{
	Electric_Heater_app();
	return 0;
}

